﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp41
{
    class Program
    {
        static void Main(string[] args)
        {
            string name0 = "Компьютер";
            string name1 = "Игрок 1";
            string name2 = "Игрок 2";
            string name3 = "Игрок 3";
            int flag = 0;
            string currentPlayer = "";
            int userTry = 0;
            int gameNumber = 30;
            Random r = new Random();

            for (; ; )
            {
                Console.WriteLine($"Игровое число: {gameNumber}");
                switch (flag)
                {
                    case 0: currentPlayer = name0;
                        break;
                    case 1:
                        currentPlayer = name1;
                        break;
                    case 2:
                        currentPlayer = name2;
                        break;
                    case 3:
                        currentPlayer = name3;
                        break;
                }

                Console.WriteLine($"Ходит: {currentPlayer}");

                if (flag == 0)
                {
                    userTry = r.Next(1, 5);
                    Console.WriteLine($"Ход {currentPlayer}: {userTry}");

                }
                else
                {
                    bool checkedNumber = true;
                    
                    while (checkedNumber)
                    {
                        Console.Write("Ход " + currentPlayer + ": ");
                        userTry = int.Parse(Console.ReadLine());

                        if (userTry > 4)
                        {
                            Console.WriteLine("Игра принимает от 1 до 4 числа");
                        }
                        else
                        {
                            checkedNumber = false;
                        }
                    }

                }

                if(gameNumber - userTry >= 0)
                {
                    gameNumber -= userTry;
                }

                flag++;
                if (flag > 3) flag = 0;

                if(gameNumber == 0)
                {
                    Console.WriteLine(currentPlayer + " выграл!");
                    break;
                }
              
            }
        }

    }
}
